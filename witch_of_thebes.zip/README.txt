This script is known as the Theban alphabet, Honorian alphabet, or the witches' alphabet. (https://en.wikipedia.org/wiki/Theban_alphabet) The characters in this font are taken and touched up from an image in the public domain. (https://en.wikipedia.org/wiki/File:Theban.jpg)

The Theban alphabet does not distinguish between I/J, U/V/W, and upper/lowercase and thus this font contains only A-Z and the symbol for full stop/period.

Font put together by IndigoAvemour and is 100% free for use.